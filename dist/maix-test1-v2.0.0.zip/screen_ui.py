"""
屏幕交互按键模块 - MaixCAM2 触摸按键与扫描结果面板

职责边界：
1) 只做触摸采集、命中判定、按键绘制、结果面板绘制
2) 不碰业务：main.py 调用 poll() 拿到按键标识，自行决定做什么

坐标系：
按键表用画面坐标系（与 camera 分辨率一致），触摸事件用屏幕坐标系。
两者在初始化时用 image.resize_map_pos 一次性换算，运行期只做屏幕坐标比较。
"""
import logging
import math
import time as pytime

from maix import image, touchscreen

logger = logging.getLogger("screen_ui")
if not logger.handlers:
    logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")


# ==================== 页面 ====================
PAGE_MAIN = "main"
PAGE_RESULT = "result"

# ==================== 按键布局（画面坐标） ====================
# 按键条压在 ROI 下方空闲带。默认 ROI (80,50,160,155) 下边界为 205，
# 因此 bar 从 212 开始，保证不遮挡任何检测区域。
BAR_Y = 212
BAR_H = 40
BUTTON_W = 77
BUTTON_START_X = 1
BUTTON_STEP_X = 80          # 77 宽 + 3 间隔
TOUCH_PAD_Y = 8             # 命中区上下外扩，补偿按键偏矮（屏上约 8mm）

# 按键表：页面 -> [(按键标识, 起始X), ...]
BUTTONS = {
    PAGE_MAIN: [
        ("scan",   BUTTON_START_X + 0 * BUTTON_STEP_X),
        ("result", BUTTON_START_X + 1 * BUTTON_STEP_X),
        ("reload", BUTTON_START_X + 2 * BUTTON_STEP_X),
        ("exit",   BUTTON_START_X + 3 * BUTTON_STEP_X),
    ],
    PAGE_RESULT: [
        ("back",   BUTTON_START_X + 0 * BUTTON_STEP_X),
        ("prev",   BUTTON_START_X + 1 * BUTTON_STEP_X),
        ("next",   BUTTON_START_X + 2 * BUTTON_STEP_X),
        ("exit",   BUTTON_START_X + 3 * BUTTON_STEP_X),
    ],
}

# 按键标签统一用 ASCII：MaixPy 默认字体只保证 ASCII 可渲染，
# 中文字形依赖设备自带 CJK 字体（需 image.load_font + set_default_font）。
LABELS = {
    "scan": "SCAN",
    "result": "INFO",
    "reload": "LOAD",
    "exit": "EXIT",
    "back": "BACK",
    "prev": "PREV",
    "next": "NEXT",
}

# 长按触发的按键（毫秒）。未列出的按键松手即触发。
LONG_PRESS_MS = {"exit": 1500}

CLICK_COOLDOWN_S = 0.25     # 一次点击后的冷却，防手抖连击

# ==================== 结果面板布局（画面坐标） ====================
PANEL_TITLE_Y = 4
PANEL_TITLE_SCALE = 0.8
PANEL_ROW_Y = 24
PANEL_ROW_H = 20
PANEL_ROWS = 9
PANEL_ROW_SCALE = 0.8


def _text_size(text):
    """兼容 string_size 的不同返回形态（对象或元组）"""
    size = image.string_size(text)
    if hasattr(size, "width"):
        return int(size.width()), int(size.height())
    return int(size[0]), int(size[1])


class ScreenUI:
    """触摸按键与结果面板"""

    def __init__(self, disp, img_width, img_height, page=PAGE_MAIN):
        self.disp = disp
        self.img_width = img_width
        self.img_height = img_height
        self.page = page

        # 步骤1： 初始化触摸屏
        # 说明：
        # 1) TouchScreen 与 Display 无耦合，可独立创建
        # 2) 首次 read 在部分固件上返回 (0,0,False)，属正常现象
        logger.info("开始初始化触摸按键: 画面=%dx%d", img_width, img_height)

        # 1.1 打开触摸设备
        self.ts = touchscreen.TouchScreen()
        logger.info("触摸屏初始化完成")

        # 步骤2： 预换算按键命中区
        # 目标：把画面坐标的按键矩形映射为屏幕坐标，运行期不再重复计算
        # 操作：
        # 1) 遍历所有页面的按键表
        # 2) 命中区上下外扩 TOUCH_PAD_Y 像素
        logger.info("开始换算按键命中区...")

        # 2.1 逐页逐键映射
        self.hit_areas = {}
        for page_name, buttons in BUTTONS.items():
            for key, bx in buttons:
                rect = image.resize_map_pos(
                    img_width, img_height,
                    disp.width(), disp.height(),
                    image.Fit.FIT_CONTAIN,
                    bx, BAR_Y - TOUCH_PAD_Y,
                    BUTTON_W, BAR_H + TOUCH_PAD_Y * 2)
                self.hit_areas[(page_name, key)] = (
                    rect[0], rect[1], rect[2], rect[3])
        logger.info("按键命中区换算完成, 共%d个按键", len(self.hit_areas))

        # 步骤3： 触摸状态机初始化
        # 说明：
        # 1) pressed 是电平信号，按住会连续为真，必须做边沿检测
        # 2) 长按键在达到阈值时立即触发，不等松手，便于显示进度
        self.pressing = False
        self.press_key = None
        self.press_start = 0.0
        self.long_fired = False
        self.last_click_time = 0.0

        logger.info("屏幕按键模块就绪, 初始页面=%s", page)

    # ------------------------------------------------------------------
    # 触摸
    # ------------------------------------------------------------------

    def _hit(self, x, y):
        """屏幕坐标命中判定，返回当前页面的按键标识或 None"""
        for key, _bx in BUTTONS[self.page]:
            rx, ry, rw, rh = self.hit_areas[(self.page, key)]
            if rx <= x <= rx + rw and ry <= y <= ry + rh:
                return key
        return None

    def hold_ratio(self):
        """长按键的按住进度，0.0~1.0，用于画进度条"""
        if not self.pressing or self.press_key not in LONG_PRESS_MS:
            return 0.0
        held_ms = (pytime.time() - self.press_start) * 1000.0
        return max(0.0, min(1.0, held_ms / LONG_PRESS_MS[self.press_key]))

    def poll(self):
        """轮询触摸，返回一次点击对应的按键标识，无事件返回 None

        事件规则：
        1) 短按键：松手时触发，且松手前的按下点必须落在按键内
        2) 长按键（LONG_PRESS_MS 里的键）：按住达到阈值时触发一次，
           松手不再触发；**短按松手一律不触发**
        3) 触发后 CLICK_COOLDOWN_S 内忽略后续点击
        """
        x, y, pressed = self.ts.read()
        now = pytime.time()

        if pressed:
            # 3.1 新一轮按下：记录起点并判命中
            if not self.pressing:
                self.pressing = True
                self.press_start = now
                self.press_key = self._hit(x, y)
                self.long_fired = False

            # 3.2 长按达到阈值即刻触发
            if (not self.long_fired
                    and self.press_key in LONG_PRESS_MS
                    and (now - self.press_start) * 1000.0
                    >= LONG_PRESS_MS[self.press_key]):
                self.long_fired = True
                logger.info("长按触发: %s", self.press_key)
                return self.press_key
            return None

        # 3.3 未按下：无进行中的按压则直接返回
        if not self.pressing:
            return None

        self.pressing = False
        key = self.press_key
        self.press_key = None

        if self.long_fired:
            self.long_fired = False
            return None
        if key is None:
            return None

        # 3.4 长按键只认长按：短按松手一律不触发
        # 否则轻碰一下 EXIT 就会退出应用，而应用退出会触发媒体框架交接，
        # 实测交接失败会让 ISP 进入坏状态（每秒刷 os04d10 越界）直至整机复位。
        if key in LONG_PRESS_MS:
            return None

        if now - self.last_click_time < CLICK_COOLDOWN_S:
            return None

        self.last_click_time = now
        logger.info("点击触发: %s", key)
        return key

    def reset_press(self):
        """丢弃进行中的按压状态，切换页面时调用"""
        self.pressing = False
        self.press_key = None
        self.long_fired = False

    def set_page(self, page):
        """切换页面"""
        if page not in BUTTONS:
            raise ValueError("未知页面: {}".format(page))
        self.page = page
        self.reset_press()

    # ------------------------------------------------------------------
    # 绘制
    # ------------------------------------------------------------------

    def draw_buttons(self, img, page=None):
        """绘制当前页面的按键条"""
        page = self.page if page is None else page
        pressed = self.press_key if self.pressing else None

        for key, bx in BUTTONS[page]:
            bg_color = image.COLOR_GREEN if key == pressed else image.COLOR_BLACK
            img.draw_rect(bx, BAR_Y, BUTTON_W, BAR_H,
                          color=bg_color, thickness=-1)
            img.draw_rect(bx, BAR_Y, BUTTON_W, BAR_H,
                          color=image.COLOR_WHITE, thickness=1)

            text = LABELS[key]
            tw, th = _text_size(text)
            img.draw_string(bx + (BUTTON_W - tw) // 2,
                            BAR_Y + (BAR_H - th) // 2,
                            text, color=image.COLOR_WHITE, scale=1.0)

            # 长按键显示按住进度
            if key == pressed and key in LONG_PRESS_MS:
                bar_w = int((BUTTON_W - 4) * self.hold_ratio())
                if bar_w > 0:
                    img.draw_rect(bx + 2, BAR_Y + BAR_H - 6, bar_w, 4,
                                  color=image.COLOR_RED, thickness=-1)

    def draw_result_panel(self, img, title, lines, page):
        """绘制扫描结果面板，返回 (实际页号, 总页数)

        lines: 每行一个字符串，行内容由调用方决定
        """
        total_pages = max(1, math.ceil(len(lines) / PANEL_ROWS)) if lines else 1
        page = max(0, min(page, total_pages - 1))

        img.draw_rect(0, 0, self.img_width, self.img_height,
                      color=image.COLOR_BLACK, thickness=-1)
        img.draw_string(4, PANEL_TITLE_Y, title,
                        color=image.COLOR_YELLOW, scale=PANEL_TITLE_SCALE)

        if not lines:
            img.draw_string(4, PANEL_ROW_Y + 20, "no scan result yet",
                            color=image.COLOR_WHITE, scale=1.0)
            return page, total_pages

        start = page * PANEL_ROWS
        for i, text in enumerate(lines[start:start + PANEL_ROWS]):
            img.draw_string(4, PANEL_ROW_Y + i * PANEL_ROW_H, text,
                            color=image.COLOR_WHITE, scale=PANEL_ROW_SCALE)

        if total_pages > 1:
            img.draw_string(self.img_width - 56, PANEL_TITLE_Y,
                            "{}/{}".format(page + 1, total_pages),
                            color=image.COLOR_GREEN, scale=PANEL_TITLE_SCALE)
        return page, total_pages
