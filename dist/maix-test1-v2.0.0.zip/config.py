"""
配置文件 - 所有可调参数集中管理
"""
import os

# ==================== 硬件配置 ====================
UART_PORT = "/dev/ttyS4"
UART_BAUDRATE = 115200


def _resolve_model_path():
    """确定模型描述文件路径

    优先用应用目录内的副本，这样整包安装后不依赖设备上预先存在的
    /root/models/model-jihe/，换机或清理模型目录都能直接跑。
    只有在应用目录内确实凑不齐 .mud 引用的权重时才退回旧路径，
    避免"本地有 .mud 但权重缺失"导致加载失败。
    """
    local_dir = os.path.dirname(os.path.abspath(__file__))
    local_mud = os.path.join(local_dir, "model_8988.mud")
    fallback = "/root/models/model-jihe/model_8988.mud"

    if not os.path.exists(local_mud):
        return fallback

    try:
        with open(local_mud, "r") as f:
            text = f.read()
        for key in ("model_npu", "model_vnpu"):
            for line in text.splitlines():
                line = line.strip()
                if line.startswith(key) and "=" in line:
                    name = line.split("=", 1)[1].strip()
                    if name and not os.path.exists(os.path.join(local_dir, name)):
                        return fallback        # 权重不在包内，退回设备目录
    except Exception:
        return fallback

    return local_mud


MODEL_PATH = _resolve_model_path()

# LED GPIO
LED_PIN_NAME = "B25"  # maixcam2
LED_GPIO_NAME = "GPIOB25"

# ==================== ROI配置 ====================
# ROI标定基准分辨率
ROI_CALIBRATION_WIDTH = 320
ROI_CALIBRATION_HEIGHT = 256

# ROI区域（基于标定分辨率）
ROI_X = 70
ROI_Y = 50
ROI_WIDTH = 170
ROI_HEIGHT = 165

# ==================== HSV颜色阈值 ====================
# 蓝色
LOWER_BLUE = [0, 132, 97]
UPPER_BLUE = [93, 255, 255]

# 黄色
LOWER_YELLOW = [52, 139, 185]
UPPER_YELLOW = [112, 255, 255]

# 红色
LOWER_RED = [40, 173, 191]
UPPER_RED = [156, 255, 255]

# 白色
LOWER_WHITE = [0, 0, 173]
UPPER_WHITE = [179, 60, 255]

# 颜色检测参数
COLOR_MIN_RATIO = 0.05  # 最小颜色占比
PIXEL_SAMPLE_STEP = 2   # 像素采样步长
COLOR_BOX_SHRINK = 0.6  # 颜色采样收缩到bbox中心区域比例(0~1)，减少边缘背景干扰

# 红色Hue环绕区间（可选）：OpenCV HSV中红色跨0点(H~0-15 和 H~170-179)
# 设置后红色掩码 = 范围1 OR 范围2，不需要时保持为 None
LOWER_RED2 = None   # 例如 [170, 173, 191]
UPPER_RED2 = None   # 例如 [179, 255, 255]

# ==================== YOLO检测参数 ====================
YOLO_CONF_THRESHOLD = 0.5
YOLO_IOU_THRESHOLD = 0.45

# ==================== 坐标转换配置 ====================
# ROI坐标映射范围（两个轴均为160mm，协议单位0.1mm）
COORD_SCALE_FACTOR = 1600
# ROI局部坐标的中点，以及该中点在机械坐标系中的标定位置
COORD_ROI_CENTER = 800
COORD_MECHANICAL_CENTER_X = 600
COORD_MECHANICAL_CENTER_Y = 1400

# ==================== 协议配置 ====================
HEARTBEAT_INTERVAL = 0.25  # 心跳间隔(秒)
LINK_TIMEOUT = 1.5         # 链路超时(秒)
DISPLAY_DURATION = 500     # 四要素显示时长(毫秒)

# ==================== 形状映射 ====================
# 模型输出 -> 协议形状ID
SHAPE_MAPPING = {
    "cube": 0x02,      # 方形
    "cone": 0x01,      # 圆形
    "pyramid": 0x03    # 三角形
}

# ==================== 颜色映射 ====================
# HSV检测结果 -> 协议颜色ID
COLOR_MAPPING = {
    "red": 0x01,
    "yellow": 0x03,
    "blue": 0x05,
    "white": 0x08
}

# ==================== 显示配置 ====================
SHOW_FPS = False
SHOW_DEBUG_INFO = True

# ==================== 屏幕交互配置 ====================
# 是否允许屏幕"扫描"键手动触发检测。
# 比赛模式下建议关闭：手动扫描与 MCU 的 SCAN_REQ 共用 scan_requested 标志位，
# 同帧到达会合并为一次扫描，导致 MCU 少收一次结果。
MANUAL_SCAN_ENABLED = True

# ==================== 启动提示 ====================
# AXERA 的媒体框架(VIN/VO/IVPS/POOL)、NPU 与 /dev/ttyS4 都是全局独占资源，
# 被抢占时会出现：相机初始化抛 VO init failed，或 uart.UART 抛
# ValueError: basic_string::_M_create / MemoryError，严重时 ISP 进坏状态
# 每秒刷 os04d10 寄存器越界，最终整机复位。
#
# 正常路径：从设备屏幕点开应用，launcher 会先释放媒体驱动再拉起本程序，
# 不会冲突。仅当从 SSH / MaixVision 直接启动、且 launcher 或其它应用还在
# 占着媒体框架时才会出问题。
#
# 这里只做提示，不阻止启动、也不结束其它进程：
# 实测从被抢占的进程内部去杀占用者会破坏 C++ 侧状态，反而触发
# _M_create / bad_alloc，所以让路必须在启动本程序之前、在外部完成。
WAIT_OTHER_APPS = True        # 是否列出仍在运行的其它 MaixCAM 应用
APP_WAIT_TIMEOUT_MS = 10000   # 保留字段
MEDIA_SETTLE_MS = 800         # 保留字段

# ==================== 诊断日志 ====================
# 每 DIAG_LOG_INTERVAL 秒把运行现场追加到 DIAG_LOG_PATH。
# 每行都 flush，程序被杀死或整机重启后仍能读到最后的现场，
# 用于排查"连着 MCU 才卡死/重启"这类只能在现场复现的问题。
DIAG_LOG_ENABLED = True
DIAG_LOG_PATH = "/root/diag.log"
DIAG_LOG_INTERVAL = 2.0

# ==================== 故障取证 ====================
# 冻结现场最有价值的信息是"主循环停在哪个调用"。冻结时进程通常还活着，
# 只是某个调用不返回，此时 kill -USR1 <pid> 就能把所有 Python 线程栈
# 写进 FAULT_DUMP_PATH，直接看到卡在哪一行，不需要额外调试工具。
# 同时 faulthandler.enable() 会在段错误等致命信号时自动转储。
FAULT_DUMP_ENABLED = True
FAULT_DUMP_PATH = "/root/fault_dump.txt"

# ==================== 扫描稳定性配置 ====================
# 扫描前准备：解决"首轮扫描漏检，后续正常"问题
# SCAN_REQ到达时托盘可能刚停稳，且摄像头缓冲区可能积压运动过程中的旧帧
SCAN_SETTLE_MS = 300        # 扫描前等待物料稳定的时间(毫秒)
SCAN_FLUSH_FRAMES = 3       # 采样前丢弃的缓冲旧帧数量

# 多帧投票检测：连续采多帧，跨帧合并，过滤偶发误检/漏检，提高稳定性
SCAN_MULTI_FRAME = True     # True=多帧投票, False=单帧检测
SCAN_FRAME_COUNT = 5        # 每次扫描采样帧数
SCAN_MIN_HITS = 3           # 目标至少在几帧中出现才上报
SCAN_MATCH_DIST = 20        # 跨帧匹配的最大中心距离(像素)
SCAN_FRAME_DELAY_MS = 50    # 帧间延迟(毫秒)

# ==================== 调试日志配置 ====================
# 扫描流程详细日志（排查漏检时开启）
SCAN_DEBUG_LOG = False
# 是否打印每个检测框的各颜色占比详情
SCAN_DEBUG_COLOR_DETAIL = False
