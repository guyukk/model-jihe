"""
智能分拣视觉系统 - 主程序入口
MaixCAM2 视觉从站
协议版本: v2.0
"""
from maix import app, camera, display, image, nn, gpio, pinmap, time, sys, err, uart
from maix import comm as maix_comm
import importlib
import os
import signal
import time as pytime

import config

# ========================================================================
# 启动闸门：先清掉占着媒体框架和串口的其它 MaixCAM 应用
# ========================================================================
# AXERA 的 VIN/VO/IVPS/POOL/NPU 与 /dev/ttyS4 都是全局独占资源。
# launcher 或其它应用还在跑时初始化，会出现两类故障：
#   1) 媒体管线被抢坏，ISP 每秒刷 os04d10 寄存器越界，最终整机复位
#   2) 紧接着创建 uart.UART 抛 ValueError: basic_string::_M_create
# 因此必须在摘除内置监听、创建串口之前，先把它们结束并等干净。
COMM_RELEASE_SETTLE_MS = 300    # 监听线程退场等待(毫秒)
UART_OPEN_RETRY = 3             # 串口打开重试次数
UART_OPEN_RETRY_DELAY_MS = 300  # 重试间隔(毫秒)


def _conflicting_processes():
    """列出占用全局媒体框架的进程

    /maixapp/apps/ 下任何应用（含 launcher 自身）在跑，
    就占着媒体框架与串口。
    """
    self_pid = os.getpid()
    found = []
    try:
        entries = os.listdir("/proc")
    except Exception:
        return found

    for name in entries:
        if not name.isdigit():
            continue
        pid = int(name)
        if pid == self_pid:
            continue
        try:
            with open("/proc/%d/cmdline" % pid, "rb") as f:
                cmd = f.read().decode("utf-8", "replace").replace("\x00", " ").strip()
        except Exception:
            continue
        if "/maixapp/apps/" not in cmd:
            continue
        found.append((pid, cmd))
    return found


def _is_launcher(cmd):
    """判断是否 launcher 相关进程

    launcher 从屏幕拉起本应用时会先把媒体驱动释放掉
    （日志里的 "maix multi-media driver used count: 0, driver released."），
    属于正常路径，不能算占用者。
    """
    return ("launcher daemon" in cmd) or ("launcher_daemon" in cmd)


def _warn_conflicting_apps():
    """启动提示：列出可能仍占着媒体框架的其它应用

    只提示，不阻止启动，也不结束它们。
    - 从设备屏幕点开应用：launcher 已完成交接，这里通常没有残留
    - 从 SSH / MaixVision 直接启动：launcher 或其它应用可能仍占着媒体框架，
      相机初始化会抛 "VO init failed"，下面会给出处理办法
    """
    if not getattr(config, "WAIT_OTHER_APPS", True):
        return

    others = [item for item in _conflicting_processes() if not _is_launcher(item[1])]
    if not others:
        return

    print("· 检测到其它 MaixCAM 应用在运行：")
    for pid, cmd in others:
        print(f"    PID={pid} {cmd}")
    print("  若接下来相机初始化失败，请先停掉它们再启动本程序。")


_warn_conflicting_apps()

# 关于 Maix 内置通信协议的摘除：
# import maix 时 maix/__init__.py 会自动调用 add_default_comm_listener()，
# 该监听常驻读取 /dev/ttyS4（A21/A22），与 MCU 链路争抢同一串口的字节。
# 摘除动作**不能放在这里**：若此刻进程里只有监听持有该口，关闭它就是关掉
# 最后一个 fd，会触发 tty hangup，紧接着打开会撞上驱动拆解，抛
# ValueError: basic_string::_M_create。因此改为在 __init__ 里
# 「先建 uart.UART 持有该口、再摘监听」，顺序见下。

import protocol as proto_module
import screen_ui
from coordinate import CoordinateConverter
from vision import VisionDetector
from protocol_handler import ProtocolHandler


class SortingVisionApp:
    """分拣视觉应用"""

    def __init__(self):
        print("=" * 50)
        print("智能分拣视觉系统启动")
        print("=" * 50)

        # 初始化GPIO
        self._init_gpio()

        # 初始化串口
        # 顺序很关键：先建 uart.UART 持有 /dev/ttyS4，再摘除内置监听。
        # 若反序，摘除监听会关掉该口上最后一个 fd，触发 tty hangup，
        # 紧接着打开就撞上驱动拆解，抛 ValueError: basic_string::_M_create。
        self.serial = None
        for attempt in range(1, UART_OPEN_RETRY + 1):
            try:
                self.serial = uart.UART(config.UART_PORT, config.UART_BAUDRATE)
                break
            except Exception as e:
                print(f"⚠ 串口打开失败(第{attempt}/{UART_OPEN_RETRY}次): "
                      f"{type(e).__name__}: {e}")
                time.sleep_ms(UART_OPEN_RETRY_DELAY_MS)
        if self.serial is None:
            raise RuntimeError(f"串口打开失败: {config.UART_PORT}")
        print(f"✓ 串口初始化: {config.UART_PORT} @ {config.UART_BAUDRATE}")

        # 已持有串口，此刻摘除内置监听不会再触发 hangup
        try:
            if maix_comm.rm_default_comm_listener():
                print("✓ 已摘除 Maix 内置通信协议，/dev/ttyS4 归本应用独占")
            else:
                print("· Maix 内置通信协议未在运行")
        except Exception as e:
            print(f"⚠ 摘除 Maix 内置通信协议失败: {e}")
        time.sleep_ms(COMM_RELEASE_SETTLE_MS)

        # 初始化协议处理器
        self.protocol = ProtocolHandler(self.serial)
        print(f"✓ 协议版本: v2.0")

        # 初始化YOLO检测器
        self.detector = nn.YOLO26(model=config.MODEL_PATH)
        print(f"✓ 模型加载: {config.MODEL_PATH}")

        # 初始化摄像头
        # Keep the calibrated camera/display geometry independent of the model input size.
        self.camera_width = config.ROI_CALIBRATION_WIDTH
        self.camera_height = config.ROI_CALIBRATION_HEIGHT

        # 媒体框架(VIN/VO/IVPS/POOL)是全局独占资源。
        # 正常从设备屏幕点开应用时 launcher 已完成交接；若从 SSH/MaixVision
        # 直接启动，其它应用可能仍占着它，这里会抛 VO init failed。
        try:
            self.cam = camera.Camera(
                self.camera_width,
                self.camera_height,
                image.Format.FMT_RGB888
            )
            print(f"✓ 摄像头: {self.camera_width}x{self.camera_height}")

            # 初始化显示器
            self.disp = display.Display()
            print(f"✓ 显示器初始化")
        except Exception as e:
            print("=" * 60)
            print(f"⚠ 媒体框架初始化失败: {type(e).__name__}: {e}")
            print("  原因通常是 launcher 或其它应用仍占着相机/显示。")
            print("  请先停掉它们再启动本程序：")
            print("    pkill -f '/maixapp/apps/launcher'")
            print("    pkill -f '/maixapp/apps/settings'")
            print("    sleep 2 && python3 main.py")
            print("  或直接把本应用设为开机自启，从设备屏幕启动。")
            print("=" * 60)
            raise

        # 初始化视觉检测器
        self.vision = VisionDetector(self.detector, self.camera_width, self.camera_height)
        print(f"✓ 视觉检测器初始化")

        # 初始化屏幕交互按键
        self.ui = screen_ui.ScreenUI(self.disp, self.camera_width, self.camera_height)
        print(f"✓ 屏幕按键初始化")

        # 最近一次扫描结果（供"INFO"键查看）
        self.result_lines = []
        self.result_title = "no scan result"
        self.result_page = 0
        self.result_total_pages = 1
        # 手动扫描的本地事务序号，用高位段与 MCU 请求区分
        self.manual_scan_seq = 0x80

        # 诊断计数
        self.loop_count = 0
        # 定时一律用单调时钟。
        # time.time() 会被系统校时跳变：后跳推迟心跳，前跳造成假的链路超时。
        # 给人看的时间戳仍用 pytime.strftime(pytime.localtime())。
        self.diag_start_time = pytime.monotonic()
        self.diag_last_time = self.diag_start_time

        # 预热YOLO检测器
        self._warmup_detector()

        # 状态名称
        self.state_names = ["INIT", "READY", "SCAN", "PICK", "DISP", "RECHK", "DUMP", "FINISH", "FAULT"]

        print("=" * 50)
        print("等待MCU连接...")
        print("=" * 50)

        # 初始化心跳时间
        self.protocol.last_mcu_heartbeat_time = pytime.monotonic()

        # 故障取证：冻结时用 kill -USR1 <pid> 取全部 Python 线程栈
        self._install_fault_dump()

    def _install_fault_dump(self):
        """注册栈转储，供冻结现场取证

        冻结时进程通常还活着，只是某个调用不返回。此时
        kill -USR1 <pid> 就能拿到所有 Python 线程栈，直接看到主循环
        停在哪一行；faulthandler.enable() 还覆盖段错误等致命信号。
        """
        if not getattr(config, "FAULT_DUMP_ENABLED", True):
            print("· 故障栈转储已在配置中关闭")
            return

        path = getattr(config, "FAULT_DUMP_PATH", "/root/fault_dump.txt")
        try:
            import faulthandler
            self._fault_file = open(path, "a")
            faulthandler.enable(file=self._fault_file, all_threads=True)

            register = getattr(faulthandler, "register", None)
            if register is not None:
                register(signal.SIGUSR1, file=self._fault_file,
                         all_threads=True, chain=False)
                print(f"✓ 故障栈转储: {path}  (kill -USR1 {os.getpid()})")
            else:
                print(f"✓ 致命信号栈转储: {path}"
                      f"（本版本无 faulthandler.register，SIGUSR1 不可用）")
        except Exception as e:
            print(f"⚠ 启用故障栈转储失败: {e}")

    def _warmup_detector(self):
        """预热YOLO检测器
        NPU首次推理需要加载图/权重缓存，耗时远高于后续推理。
        若不预热，第一次扫描会因超时或空结果导致首轮漏检。
        """
        print("预热YOLO检测器(首次推理较慢，请等待)...")
        warmup_count = 3
        for i in range(warmup_count):
            start = pytime.monotonic()
            warmup_img = self.cam.read()
            self.detector.detect(warmup_img,
                                 conf_th=config.YOLO_CONF_THRESHOLD,
                                 iou_th=config.YOLO_IOU_THRESHOLD)
            elapsed = (pytime.monotonic() - start) * 1000
            print(f"  预热推理 #{i + 1}: {elapsed:.0f}ms")
        print("✓ 检测器预热完成")

    def _init_gpio(self):
        """初始化GPIO（LED）"""
        try:
            pin_name = config.LED_PIN_NAME if sys.device_id() == "maixcam2" else "B3"
            gpio_name = config.LED_GPIO_NAME if sys.device_id() == "maixcam2" else "GPIOB3"

            err.check_raise(pinmap.set_pin_function(pin_name, gpio_name), "set pin failed")
            self.led = gpio.GPIO(gpio_name, gpio.Mode.OUT)
            self.led.value(0)
            print(f"✓ GPIO初始化: {pin_name} -> {gpio_name}")
        except Exception as e:
            print(f"⚠ GPIO初始化失败: {e}")
            self.led = None

    def _draw_status(self, img):
        """绘制状态信息"""
        # 状态文本
        state = self.protocol.current_state
        state_text = self.state_names[state] if state < len(self.state_names) else "UNKN"

        # 链路状态
        link_text = "LINK" if self.protocol.link_alive else "DISC"
        link_color = image.COLOR_GREEN if self.protocol.link_alive else image.COLOR_RED

        # 绘制状态
        img.draw_string(5, 5, f"{state_text}", color=image.COLOR_GREEN, scale=1.2)
        img.draw_string(5, 25, f"{link_text}", color=link_color, scale=1.0)

    def _execute_scan(self):
        """执行扫描检测（含稳定等待、旧帧冲刷、多帧投票）
        返回: (detections, scan_img) scan_img为实际用于检测的干净帧
        """
        # 扫描前准备：等待物料稳定 + 冲刷摄像头缓冲区旧帧
        # 解决"首轮扫描漏检"：请求到达时托盘可能刚停稳（画面模糊），
        # 且缓冲区可能积压运动过程中的旧帧
        settle_ms = getattr(config, "SCAN_SETTLE_MS", 0)
        flush_frames = getattr(config, "SCAN_FLUSH_FRAMES", 0)
        if settle_ms > 0:
            print(f"[SCAN] 等待物料稳定 {settle_ms}ms...")
            # 等待期间继续收串口、发心跳，避免 MCU 判定掉线
            self._pump(settle_ms)
        if flush_frames > 0:
            for _ in range(flush_frames):
                self.cam.read()
            print(f"[SCAN] 已冲刷{flush_frames}帧缓冲区旧帧")

        # 执行检测（使用干净帧，含详细过程日志）
        if getattr(config, "SCAN_MULTI_FRAME", False):
            # 多帧投票：每次读取新的干净帧
            detections = self.vision.detect_objects_stable(
                lambda: self.cam.read(),
                service_protocol=self.protocol.update, wait_ms=self._pump)
            scan_img = self.cam.read()  # 用于结果显示的干净帧
        else:
            # 单帧：重新读取干净帧（不要用绘制过标注的图）
            scan_img = self.cam.read()
            detections = self.vision.detect_objects(scan_img)

        return detections, scan_img

    def _handle_scan_request(self, img):
        """处理扫描请求
        返回: (detections, scan_img) scan_img为实际用于检测的干净帧
        """
        # 从队列取一条请求，并把 SEQ 固定在本轮局部变量里。
        # 扫描期间的等待与屏显都会继续收串口，新的 SCAN_REQ 会改写
        # 共享的 scan_req_seq；若发送时再去读共享字段，本轮就会用错序号，
        # 而队列里那条新请求还会被重复应答。
        req_seq = self.protocol.take_scan_request()
        if req_seq is not None:
            print(f"[SCAN] 处理请求 seq={req_seq:02X}，"
                  f"队列剩余{len(self.protocol.scan_req_queue)}条")
        self.protocol.current_state = proto_module.Protocol.STATE_SCANNING

        print("[SCAN] 开始执行扫描...")

        # 显示扫描中
        # 注意：该文字及之前绘制的ROI框/状态文字会污染图像，
        # 检测前必须重新读取干净帧，严禁在绘制过的图上检测！
        img.draw_string(80, 100, "Scanning...", color=image.COLOR_YELLOW, scale=1.5)
        self.disp.show(img)

        # 执行检测（含详细过程日志）
        scan_start = pytime.monotonic()
        detections, scan_img = self._execute_scan()
        scan_elapsed = (pytime.monotonic() - scan_start) * 1000

        # 发送结果，显式带上本轮固定的 SEQ
        sent_count = self.protocol.send_scan_result(
            detections, req_seq, wait_ms=self._pump)

        # 打印本次扫描总结
        stats = self.vision.last_scan_stats
        print(f"[SCAN] 扫描完成: 耗时{scan_elapsed:.0f}ms, "
              f"YOLO检出={stats['yolo_raw']}, ROI外剔除={stats['roi_out']}, "
              f"颜色未识别={stats['color_unknown']}, 实际上报={sent_count}")

        # 返回READY状态
        self.protocol.current_state = proto_module.Protocol.STATE_READY

        return detections, scan_img

    def _handle_recheck_request(self, img):
        """处理复核请求：重新扫描并与MCU期望清单比对
        返回: (detections, scan_img)
        """
        self.protocol.recheck_requested = False
        self.protocol.current_state = proto_module.Protocol.STATE_RECHECKING

        # 本轮事务的期望清单与 SEQ 必须在这里固定成本地快照。
        # 复核扫描期间会继续收串口，新的 RECHECK_REQ 会改写共享字段，
        # 若等扫描结束后再去读，本轮就会用下一份清单做判定。
        expected = list(self.protocol.recheck_expected)
        req_seq = self.protocol.recheck_req_seq

        print(f"[RECHECK] 开始复核扫描... (seq={req_seq:02X}, "
              f"期望{len(expected)}件)")

        img.draw_string(80, 100, "Rechecking...", color=image.COLOR_YELLOW, scale=1.5)
        self.disp.show(img)

        # 复用扫描流程
        scan_start = pytime.monotonic()
        detections, scan_img = self._execute_scan()
        scan_elapsed = (pytime.monotonic() - scan_start) * 1000

        # 比对并发送复核结果，显式带上本轮固定的清单与 SEQ
        match, sent_count = self.protocol.send_recheck_result(
            expected, detections, req_seq)

        print(f"[RECHECK] 复核完成: 耗时{scan_elapsed:.0f}ms, "
              f"期望{len(expected)}件, 实际{sent_count}件, "
              f"{'✓ 一致' if match else '✗ 不一致'}")

        # 返回READY状态
        self.protocol.current_state = proto_module.Protocol.STATE_READY

        return detections, scan_img

    def _pump(self, ms, img=None, step_ms=30):
        """等待期间持续服务协议与显示

        扫描的稳定等待、PICK/DUMP/FINISH 的屏显会占用几百毫秒到 2 秒。
        这段时间如果不收串口、不发心跳，MCU 会判定掉线并重试；
        重试又会把扫描请求队列填满。这里把等待切成小片，
        每片都跑一次 protocol.update()，让心跳与收帧保持连续。
        """
        deadline = pytime.monotonic() + ms / 1000.0
        while not app.need_exit():
            self.protocol.update()
            if app.need_exit():
                break
            if img is not None:
                self.disp.show(img)
            remain = deadline - pytime.monotonic()
            if remain <= 0:
                break
            # 下限 1ms：避免算出 0 让 sleep_ms 变成空转
            time.sleep_ms(max(1, int(min(step_ms, remain * 1000))))

    def _handle_dump_display(self, img):
        """处理倾倒完成显示"""
        if not self.protocol.dump_display_pending:
            return False

        self.protocol.dump_display_pending = False
        self.protocol.current_state = proto_module.Protocol.STATE_DUMPING

        img.draw_rect(0, 100, self.camera_width, 60,
                      color=image.COLOR_BLACK, thickness=-1)
        img.draw_string(60, 115, "Dump Done", color=image.COLOR_GREEN, scale=1.5)
        self.disp.show(img)
        self._pump(config.DISPLAY_DURATION, img)

        self.protocol.current_state = proto_module.Protocol.STATE_READY
        return True

    def _handle_finish_display(self, img):
        """处理比赛结束显示（保持FINISHED状态）"""
        if self.protocol.finish_display_pending is None:
            return False

        total_ok, total, elapsed_s = self.protocol.finish_display_pending
        self.protocol.finish_display_pending = None

        img.draw_rect(0, 50, self.camera_width, 150,
                      color=image.COLOR_BLACK, thickness=-1)
        img.draw_string(20, 60, "Match Finished!", color=image.COLOR_YELLOW, scale=1.5)
        img.draw_string(20, 95, f"OK: {total_ok}/{total}", color=image.COLOR_GREEN, scale=1.5)
        img.draw_string(20, 130, f"Time: {elapsed_s}s", color=image.COLOR_WHITE, scale=1.5)
        self.disp.show(img)
        self._pump(2000, img)

        # 保持FINISHED状态，等待MCU后续指令
        return True

    def _handle_pick_display(self, img):
        """处理PICK_REPORT显示"""
        if not self.protocol.pick_report_queue:
            return False

        self.protocol.current_state = proto_module.Protocol.STATE_DISPLAYING

        req_seq, seq_no, shape, color, res, total_ok = self.protocol.pick_report_queue.pop(0)
        self._diag_event("PICK 序号=%d 形状=%d 颜色=%d 结果=%d"
                         % (seq_no, shape, color, res))

        # 获取名称
        shape_name = proto_module.SHAPE_NAMES.get(shape, "未知")
        color_name = proto_module.COLOR_NAMES.get(color, "未知")
        result_text = "✓ 成功" if res == proto_module.Protocol.R_OK else "✗ 失败"
        result_color = image.COLOR_GREEN if res == proto_module.Protocol.R_OK else image.COLOR_RED

        # 显示失败不影响协议应答，绘制过程做容错
        try:
            # 安全取色：部分颜色常量在某些MaixPy版本不存在(如COLOR_CYAN)
            cyan = getattr(image, "COLOR_CYAN", image.COLOR_WHITE)

            # 清空背景
            img.draw_rect(0, 50, self.camera_width, 150, color=image.COLOR_BLACK, thickness=-1)

            # 显示四要素
            img.draw_string(20, 60, f"序号: {seq_no}", color=image.COLOR_WHITE, scale=1.5)
            img.draw_string(20, 90, f"{shape_name} {color_name}", color=cyan, scale=1.5)
            img.draw_string(20, 120, result_text, color=result_color, scale=1.5)
            img.draw_string(20, 150, f"累计: {total_ok}", color=image.COLOR_YELLOW, scale=1.5)

            self.disp.show(img)
            self._pump(config.DISPLAY_DURATION, img)
        except Exception as e:
            print(f"⚠ PICK_REPORT显示异常(不影响应答): {e}")

        # 发送应答（必须执行，否则MCU会一直等待）
        self.protocol.send_pick_ack(req_seq)
        print(f"✓ 已显示并应答PICK_REPORT #{seq_no}")

        self.protocol.current_state = proto_module.Protocol.STATE_READY
        return True

    def _capture_scan_result(self):
        """把最近一次上报的物料快照转成结果面板文本行"""
        # 步骤1： 读取最近一次上报的物料快照
        # 数据源：ProtocolHandler.last_scan_pieces，元素为
        #        (shape_id, color_id, mech_x, mech_y, angle)
        # 1.1 取快照
        pieces = getattr(self.protocol, "last_scan_pieces", None) or []
        stamp = pytime.strftime("%H:%M:%S", pytime.localtime())

        # 步骤2： 转成面板文本行
        # 行格式：#序号 S:形状ID C:颜色ID X:机械X Y:机械Y
        # ID 为协议十六进制值，坐标单位 0.1mm
        # 2.1 逐件生成一行
        self.result_lines = [
            f"#{i + 1} S:{shape_id:02X} C:{color_id:02X} X:{x} Y:{y}"
            for i, (shape_id, color_id, x, y, angle) in enumerate(pieces)
        ]

        # 2.2 生成标题并回到第一页
        self.result_title = f"last {len(pieces)}pcs @{stamp} S/C hex XY0.1mm"
        self.result_page = 0
        print(f"[UI] 已缓存扫描结果 {len(pieces)} 件")

    def _reload_config(self):
        """重新加载 ROI 标定与 HSV 阈值，不必重启进程

        全部构件都先建成临时对象，成功后才统一替换。
        否则 reload(config) 已经改掉了共享配置，一旦后续构造失败，
        就会出现"新配置 + 旧检测器 + 旧转换器"的混合状态。
        """
        print("[UI] 开始重载配置...")

        # 步骤1： 备份 reload 之前的配置常量，供失败回滚
        snapshot = {k: v for k, v in vars(config).items() if k.isupper()}

        # 步骤2： 在临时对象上完成全部构造
        try:
            importlib.reload(config)
            new_vision = VisionDetector(self.detector,
                                        self.camera_width, self.camera_height)
            # 比例因子在构造时写入，不重建则 COORD_SCALE_FACTOR 仍旧值
            new_converter = CoordinateConverter()
        except Exception as e:
            # 2.1 回滚：把 config 的公开常量写回 reload 之前的值，
            #     检测器与转换器保持原样，三者仍然一致
            for k, v in snapshot.items():
                setattr(config, k, v)
            print(f"⚠ 配置重载失败，已回滚到原配置: {e}")
            return

        # 步骤3： 全部成功后再统一生效
        self.vision = new_vision
        self.protocol.converter = new_converter
        print("✓ 已重载 ROI/HSV 配置")

    def _on_button(self, key):
        """处理屏幕按键事件"""
        # 步骤1： 手动扫描
        # 说明：复用 MCU 的 scan_requested 通路，自行补一个事务序号。
        #      该序号取 0x80 起始的高位段，便于在日志里与 MCU 请求区分。
        if key == "scan":
            if not config.MANUAL_SCAN_ENABLED:
                print("⚠ 屏幕手动扫描已在配置中禁用")
                return
            self.protocol.scan_req_seq = self.manual_scan_seq
            self.manual_scan_seq = (self.manual_scan_seq + 1) & 0xFF
            self.protocol.scan_requested = True
            print(f"[UI] 手动触发扫描, SEQ={self.protocol.scan_req_seq:02X}")

        # 步骤2： 结果面板的进入与翻页
        elif key == "result":
            self.ui.set_page(screen_ui.PAGE_RESULT)
            self.result_page = 0
            print("[UI] 打开扫描结果面板")

        elif key == "back":
            self.ui.set_page(screen_ui.PAGE_MAIN)
            print("[UI] 返回主界面")

        elif key == "prev":
            self.result_page = max(0, self.result_page - 1)

        elif key == "next":
            self.result_page = min(max(0, self.result_total_pages - 1),
                                   self.result_page + 1)

        # 步骤3： 重载配置
        elif key == "reload":
            self._reload_config()

        # 步骤4： 退出
        # 说明：exit 为长按键，能走到这里说明已按住 1.5s
        elif key == "exit":
            print("[UI] 长按确认退出")
            app.set_exit_flag(True)

    @staticmethod
    def _read_proc_value(path, key):
        """从 /proc 文件里取一行数值（单位 kB），失败返回 -1"""
        try:
            with open(path, "r") as f:
                for line in f:
                    if line.startswith(key):
                        return int(line.split()[1])
        except Exception:
            pass
        return -1

    @staticmethod
    def _read_uptime():
        """系统开机时长(秒)，归零说明整机重启过"""
        try:
            with open("/proc/uptime", "r") as f:
                return float(f.read().split()[0])
        except Exception:
            return -1.0

    def _diag_tick(self):
        """步骤1： 周期性落盘运行现场

        目的：卡死/重启后仍能读到现场。stdout 上的日志随进程一起丢，
        这里每行 flush 到 eMMC 上的文件，重启后依然可读。

        记录内容：
        1) 系统开机时长 —— 归零即为整机重启，不归零说明只是进程退出
        2) 循环速率 —— 掉到接近 0 说明主循环被拖死
        3) MCU 命令直方图与接收字节 —— 判断对端是否在灌数据
        4) 串口最大单次读取与缓冲残留 —— 判断是否出现突发
        5) 进程 RSS 与系统可用内存 —— 判断是否内存泄漏
        """
        if not getattr(config, "DIAG_LOG_ENABLED", False):
            return

        now = pytime.monotonic()
        interval = getattr(config, "DIAG_LOG_INTERVAL", 5.0)
        if now - self.diag_last_time < interval:
            return
        self.diag_last_time = now

        # 1.1 采集运行指标
        rss = self._read_proc_value("/proc/self/status", "VmRSS:")
        avail = self._read_proc_value("/proc/meminfo", "MemAvailable:")
        elapsed = now - self.diag_start_time
        rate = self.loop_count / elapsed if elapsed > 0 else 0.0

        # 1.2 拼命令直方图，只取最多的前6个
        top = sorted(self.protocol.cmd_counts.items(), key=lambda kv: -kv[1])[:6]
        cmds = " ".join("%02X=%d" % (c, n) for c, n in top) or "-"

        # 1.3 落盘
        line = ("t=%.0fs up=%.0fs loop=%d(%.1f/s) scan=%d rechk=%d "
                "rx=%dB/%d帧 maxchunk=%d buf=%d txerr=%d pickdrop=%d "
                "crc=%d badlen=%d drop=%d rss=%dkB avail=%dkB cmd[%s]"
                % (elapsed, self._read_uptime(), self.loop_count, rate,
                   self.protocol.scan_count, self.protocol.recheck_count,
                   self.protocol.rx_bytes_total, self.protocol.rx_frames_total,
                   self.protocol.max_rx_chunk, len(self.protocol.proto.rx_buffer),
                   self.protocol.write_error_count, self.protocol.pick_drop_count,
                   self.protocol.proto.crc_errors, self.protocol.proto.bad_len,
                   self.protocol.proto.dropped_bytes,
                   rss, avail, cmds))
        try:
            with open(getattr(config, "DIAG_LOG_PATH", "/root/diag.log"), "a") as f:
                f.write(line + "\n")
                f.flush()
        except Exception as e:
            print(f"⚠ 诊断日志写入失败: {e}")

    def _diag_event(self, text):
        """把关键事件立即落盘（带相对时间戳），供崩溃/重启后回溯

        比 2 秒一次的周期快照更贴近现场：媒体池损坏往往只发生在
        一两秒之内，事件行能对上当时在处理哪条 MCU 命令。
        """
        if not getattr(config, "DIAG_LOG_ENABLED", False):
            return
        try:
            with open(getattr(config, "DIAG_LOG_PATH", "/root/diag.log"), "a") as f:
                f.write("EVT t=%.1fs loop=%d %s\n"
                        % (pytime.monotonic() - self.diag_start_time,
                           self.loop_count, text))
                f.flush()
        except Exception:
            pass

    def run(self):
        """主循环"""
        try:
            while not app.need_exit():
                # 更新协议
                self.protocol.update()

                # 诊断计数与落盘（放在耗时分支之前，保证每轮都执行）
                self.loop_count += 1
                self._diag_tick()

                # 读取图像
                img = self.cam.read()

                # 绘制ROI
                self.vision.draw_roi(img)

                # 绘制状态
                self._draw_status(img)

                # 处理扫描请求
                if self.protocol.scan_requested:
                    self._diag_event("SCAN_REQ seq=%02X" % self.protocol.scan_req_seq)
                    detections, img = self._handle_scan_request(img)
                    self._diag_event("SCAN_DONE 上报=%d"
                                     % len(self.protocol.last_scan_pieces))
                    self._capture_scan_result()
                    # 在实际用于检测的干净帧上标记检测结果
                    if detections:
                        self.vision.draw_detections(img, detections)

                # 处理复核请求
                if self.protocol.recheck_requested:
                    self._diag_event("RECHECK_REQ")
                    detections, img = self._handle_recheck_request(img)
                    self._diag_event("RECHECK_DONE")
                    self._capture_scan_result()
                    if detections:
                        self.vision.draw_detections(img, detections)

                # 处理屏幕按键（放在耗时显示之前，保证按键优先被消费）
                key = self.ui.poll()
                if key is not None:
                    self._on_button(key)

                # 处理PICK显示
                if self._handle_pick_display(img):
                    continue  # 已在显示中刷新过

                # 处理倾倒完成显示
                if self._handle_dump_display(img):
                    continue

                # 处理比赛结束显示
                if self._handle_finish_display(img):
                    continue

                # 结果面板覆盖整屏
                if self.ui.page == screen_ui.PAGE_RESULT:
                    self.result_page, self.result_total_pages = self.ui.draw_result_panel(
                        img, self.result_title, self.result_lines, self.result_page)

                # 绘制按键条
                self.ui.draw_buttons(img)

                # 正常显示
                self.disp.show(img)
                time.sleep_ms(30)

        except KeyboardInterrupt:
            print("\n用户中断")
        except Exception as e:
            print(f"\n错误: {e}")
            import traceback
            traceback.print_exc()
        finally:
            self.cleanup()

    def cleanup(self):
        """清理资源"""
        if self.led:
            self.led.value(0)
        print("程序退出")


def main():
    """入口函数"""
    # 步骤1： 安装优雅退出处理
    # 背景：MaixCAM 上应用被 SIGTERM 强杀时，媒体/ISP 管线会留下残留，
    #      下一个进程初始化摄像头会撞上
    #        ax_isp_iq_cfg_set_hdr: pipe[0] work on sdr, not support to set hdr param
    #        AX_ISP_ALG_AeInit: Lens Iris Init Failed
    #      随后 ISP 进入坏状态，每秒刷 os04d10 寄存器越界，十几分钟后整机复位。
    #      实测：每次 launcher.service 被停、应用收到 signal 15，几秒内洪流就开始。
    #      这里把信号转成正常退出请求，让主循环走完 finally 里的清理。
    def _graceful_exit(signum, _frame):
        print(f"\n收到信号 {signum}，请求正常退出")
        app.set_exit_flag(True)

    for _sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        try:
            signal.signal(_sig, _graceful_exit)
        except Exception as e:
            print(f"⚠ 注册信号 {_sig} 处理失败: {e}")

    # 步骤2： 启动应用主循环
    vision_app = SortingVisionApp()
    vision_app.run()


if __name__ == "__main__":
    main()
