"""
坐标转换模块 - 处理归一化坐标到机械坐标的转换
"""
import config


class CoordinateConverter:
    """坐标转换器"""

    def __init__(self):
        self.scale_factor = config.COORD_SCALE_FACTOR

    def normalized_to_mechanical(self, norm_x, norm_y):
        """
        将ROI归一化坐标转换为机械坐标

        根据协议和实际测试:
        msg = f"{class_id},{160*norm_y:.1f},{160*norm_x:.1f}\r\n"

        机械坐标系:
        - X轴（机械第一个坐标）= norm_y * 160 * 10  (0.1mm单位)
        - Y轴（机械第二个坐标）= norm_x * 160 * 10  (0.1mm单位)

        这里包含了90度旋转变换：视觉X->机械Y，视觉Y->机械X

        Args:
            norm_x: 视觉归一化X坐标 (0-1)
            norm_y: 视觉归一化Y坐标 (0-1)

        Returns:
            (mech_x, mech_y): 机械坐标，单位0.1mm
        """
        # 视觉Y -> 机械X
        mech_x = int(norm_y * self.scale_factor)

        # 视觉X -> 机械Y
        mech_y = int(norm_x * self.scale_factor)

        return mech_x, mech_y

    def mechanical_to_mm(self, mech_x, mech_y):
        """
        将机械坐标(0.1mm单位)转换为毫米

        Args:
            mech_x: 机械X坐标 (0.1mm单位)
            mech_y: 机械Y坐标 (0.1mm单位)

        Returns:
            (x_mm, y_mm): 坐标，单位mm
        """
        return mech_x / 10.0, mech_y / 10.0
