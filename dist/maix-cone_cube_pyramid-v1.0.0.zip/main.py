import cv2
import numpy as np

from maix import app, camera, display, image, nn, gpio, pinmap, time, sys, err, uart, protocol

pin_name = "B25" if sys.device_id() == "maixcam2" else "B3"
gpio_name = "GPIOB25" if sys.device_id() == "maixcam2" else "GPIOB3"

err.check_raise(pinmap.set_pin_function(pin_name, gpio_name), "set pin failed")
led = gpio.GPIO(gpio_name, gpio.Mode.OUT)
led.value(0)

# 初始化串口 UART4 (A21 为 TX)
serial = uart.UART("/dev/ttyS4", 115200)
proto = protocol.Protocol()

MODEL = "/root/models/model-jihe/model_8988.mud"

# ROI配置（基于320x256分辨率标定）
roi = {
    "x": 70,
    "y": 60,
    "width": 170,
    "height": 165
}

# HSV thresholds. OpenCV uses H in the range [0, 179].
# 标定结果 - 2024标定
LOWER_BLUE1 = np.array([0, 132, 97], dtype=np.uint8)
UPPER_BLUE1 = np.array([93, 255, 255], dtype=np.uint8)
LOWER_YELLOW = np.array([52, 139, 185], dtype=np.uint8)
UPPER_YELLOW = np.array([112, 255, 255], dtype=np.uint8)
LOWER_RED = np.array([40, 173, 191], dtype=np.uint8)
UPPER_RED = np.array([156, 255, 255], dtype=np.uint8)
LOWER_WHITE = np.array([0, 0, 173], dtype=np.uint8)
UPPER_WHITE = np.array([179, 60, 255], dtype=np.uint8)  # S上限改为60，H范围扩大到全范围

COLOR_MIN_RATIO = 0.05
PIXEL_SAMPLE_STEP = 2

# 检测稳定性参数
STABLE_FRAMES = 5  # 需要连续检测到相同结果的帧数
last_detections = []  # 存储最近的检测结果
send_request = False  # 是否收到发送请求


def _red_mask(hsv_roi):
    """Build the red mask using the calibrated thresholds."""
    # 直接使用标定的红色阈值
    return cv2.inRange(hsv_roi, LOWER_RED, UPPER_RED)


def detect_color(hsv_roi):
    """Return the dominant configured color and its pixel ratio in an ROI."""
    masks = {
        "blue": cv2.inRange(hsv_roi, LOWER_BLUE1, UPPER_BLUE1),
        "yellow": cv2.inRange(hsv_roi, LOWER_YELLOW, UPPER_YELLOW),
        "red": _red_mask(hsv_roi),
        "white": cv2.inRange(hsv_roi, LOWER_WHITE, UPPER_WHITE),
    }
    roi_area = hsv_roi.shape[0] * hsv_roi.shape[1]
    if roi_area == 0:
        return "unknown", 0.0

    color, pixel_count = max(
        ((name, cv2.countNonZero(mask)) for name, mask in masks.items()),
        key=lambda item: item[1],
    )
    ratio = pixel_count / roi_area
    if ratio < COLOR_MIN_RATIO:
        return "unknown", ratio
    return color, ratio


def _get_rgb_pixel(img, x, y):
    """Read one RGB pixel from a MaixPy Image in a NumPy-friendly form."""
    pixel = img.get_pixel(x, y)
    if isinstance(pixel, (tuple, list)):
        if len(pixel) >= 3:
            return pixel[0], pixel[1], pixel[2]
        if len(pixel) == 1:
            # RGB888 may be returned as a one-element list containing the
            # packed 0xRRGGBB value (including values smaller than 0x100).
            pixel = pixel[0]
        else:
            return 0, 0, 0

    # The camera is configured for RGB888, so interpret scalar pixels as
    # packed 0xRRGGBB values instead of losing colors such as pure blue.
    pixel = int(pixel)
    return (pixel >> 16) & 0xFF, (pixel >> 8) & 0xFF, pixel & 0xFF


def detect_color_in_box(img, x1, y1, x2, y2):
    """Sample a detection box and classify it with the configured HSV masks."""
    width = x2 - x1
    height = y2 - y1
    if width <= 0 or height <= 0:
        return "unknown", 0.0

    # Image.to_numpy() is not available in the MaixCAM2 firmware. Sampling
    # directly through get_pixel keeps the OpenCV HSV processing portable.
    step = PIXEL_SAMPLE_STEP
    sample_width = (width + step - 1) // step
    sample_height = (height + step - 1) // step
    rgb_roi = np.empty((sample_height, sample_width, 3), dtype=np.uint8)
    for sample_y, y in enumerate(range(y1, y2, step)):
        for sample_x, x in enumerate(range(x1, x2, step)):
            rgb_roi[sample_y, sample_x] = _get_rgb_pixel(img, x, y)

    hsv_roi = cv2.cvtColor(rgb_roi, cv2.COLOR_RGB2HSV)
    return detect_color(hsv_roi)


def is_in_roi(center_x, center_y, roi_config):
    """检查物体中心坐标是否在ROI矩形内"""
    if roi_config is None:
        return True  # 未配置ROI时，所有检测都有效

    x_in = roi_config["x"] <= center_x <= roi_config["x"] + roi_config["width"]
    y_in = roi_config["y"] <= center_y <= roi_config["y"] + roi_config["height"]
    return x_in and y_in


def normalize_coordinates(center_x, center_y, roi_config):
    """
    将物体坐标归一化到ROI坐标系（0-1范围）

    Args:
        center_x: 物体中心X坐标（相对于整个画面）
        center_y: 物体中心Y坐标（相对于整个画面）
        roi_config: ROI配置字典

    Returns:
        (norm_x, norm_y): 归一化后的坐标，范围[0, 1]
    """
    if roi_config is None:
        # 未配置ROI时，返回原始坐标（不归一化）
        return center_x, center_y

    # 计算相对于ROI左上角的偏移
    rel_x = center_x - roi_config["x"]
    rel_y = center_y - roi_config["y"]

    # 归一化到0-1范围
    norm_x = rel_x / roi_config["width"]
    norm_y = rel_y / roi_config["height"]

    # 限制在[0, 1]范围内（防止浮点误差）
    norm_x = max(0.0, min(1.0, norm_x))
    norm_y = max(0.0, min(1.0, norm_y))

    return norm_x, norm_y

detector = nn.YOLO26(model=MODEL)
# Request a color frame explicitly. Relying on input_format() can produce a
# grayscale camera image on firmware versions where the model format metadata
# is reported as format 0, which makes every HSV pixel have S == 0.
CAMERA_WIDTH = detector.input_width()
CAMERA_HEIGHT = detector.input_height()
cam = camera.Camera(
    CAMERA_WIDTH,
    CAMERA_HEIGHT,
    image.Format.FMT_RGB888,
)
disp = display.Display()

# ROI坐标缩放：将320x256标定的ROI缩放到实际摄像头分辨率
ROI_CALIBRATION_WIDTH = 320
ROI_CALIBRATION_HEIGHT = 256
if roi is not None:
    scale_x = CAMERA_WIDTH / ROI_CALIBRATION_WIDTH
    scale_y = CAMERA_HEIGHT / ROI_CALIBRATION_HEIGHT
    roi_scaled = {
        "x": int(roi["x"] * scale_x),
        "y": int(roi["y"] * scale_y),
        "width": int(roi["width"] * scale_x),
        "height": int(roi["height"] * scale_y)
    }
    print(f"摄像头分辨率: {CAMERA_WIDTH}x{CAMERA_HEIGHT}")
    print(f"ROI缩放比例: x={scale_x:.3f}, y={scale_y:.3f}")
    print(f"缩放后ROI: ({roi_scaled['x']}, {roi_scaled['y']}) {roi_scaled['width']}x{roi_scaled['height']}")
else:
    roi_scaled = None
    print(f"摄像头分辨率: {CAMERA_WIDTH}x{CAMERA_HEIGHT}")

try:
    while not app.need_exit():
        # 检查串口是否收到发送请求
        if serial.available() >= 3:
            data = serial.read(3)
            if data == b'\xA1\x01\xA2':
                send_request = True

        img = cam.read()

        # 如果配置了ROI，在画面上绘制ROI矩形（使用缩放后的坐标）
        if roi_scaled is not None:
            img.draw_rect(
                roi_scaled["x"],
                roi_scaled["y"],
                roi_scaled["width"],
                roi_scaled["height"],
                color=image.COLOR_BLUE,
                thickness=2
            )

        objects = detector.detect(img, conf_th=0.5, iou_th=0.45)

        # 收集当前帧的检测结果
        current_detections = []
        for obj in objects:
            x1 = max(0, int(obj.x))
            y1 = max(0, int(obj.y))
            x2 = min(detector.input_width(), x1 + max(0, int(obj.w)))
            y2 = min(detector.input_height(), y1 + max(0, int(obj.h)))

            # 计算物体中心坐标
            center_x = int(obj.x + obj.w / 2)
            center_y = int(obj.y + obj.h / 2)

            # 检查是否在ROI内（使用缩放后的ROI）
            if not is_in_roi(center_x, center_y, roi_scaled):
                continue  # 跳过ROI外的检测

            # 归一化坐标到ROI范围（0-1），使用缩放后的ROI
            norm_x, norm_y = normalize_coordinates(center_x, center_y, roi_scaled)

            color_name, color_ratio = detect_color_in_box(img, x1, y1, x2, y2)

            # 根据形状+颜色组合确定新的编号
            shape_name = detector.labels[obj.class_id]

            # 编号规则：
            # 1 = cube + blue
            # 2 = cube + red
            # 3 = cone + blue
            # 4 = cone + red
            # 5 = pyramid (任意颜色)
            if shape_name == "cube":
                if color_name == "blue":
                    combined_id = 1
                elif color_name == "red":
                    combined_id = 2
                else:
                    combined_id = 0  # 其他颜色暂不支持
            elif shape_name == "cone":
                if color_name == "blue":
                    combined_id = 3
                elif color_name == "red":
                    combined_id = 4
                else:
                    combined_id = 0
            elif shape_name == "pyramid":
                combined_id = 5
            else:
                combined_id = 0  # 未知形状

            img.draw_rect(obj.x, obj.y, obj.w, obj.h, color=image.COLOR_RED)
            # 显示归一化后的坐标和新编号
            img.draw_string(
                obj.x,
                obj.y,
                f"ID{combined_id} {shape_name} {color_name}: {obj.score:.2f}",
                color=image.COLOR_RED,
            )
            img.draw_string(
                obj.x,
                obj.y + 20,
                f"norm:({norm_x:.2f},{norm_y:.2f})",
                color=image.COLOR_GREEN,
            )

            # 记录检测结果：组合后的ID、归一化坐标
            current_detections.append((combined_id, norm_x, norm_y))

        # 更新检测历史
        last_detections.append(current_detections)
        if len(last_detections) > STABLE_FRAMES:
            last_detections.pop(0)

        # 检查是否稳定且收到发送请求
        if send_request and len(last_detections) == STABLE_FRAMES:
            detection_counts = [len(d) for d in last_detections]
            if len(set(detection_counts)) == 1 and detection_counts[0] > 0:
                # 检测稳定，发送数据
                for class_id, norm_x, norm_y in current_detections:
                    # 发送格式：类别ID, 归一化X坐标, 归一化Y坐标
                    msg = f"{class_id},{160*norm_y:.4f},{160*norm_x:.4f}\r\n"
                    serial.write(msg.encode())
                    print(f"发送: 类别{class_id}, 坐标({norm_x:.4f}, {norm_y:.4f})")
                # 发送完成后清除请求标志
                send_request = False

        disp.show(img)
finally:
    led.value(0)
